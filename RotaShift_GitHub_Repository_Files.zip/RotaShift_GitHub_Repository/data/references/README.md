# BARC / BRRI reference tables

These workbooks and CSVs were supplied in `CSV & Code file-2.zip`. They support the extracted BARC table and BRRI CROPWAT water-reference information. They are reference data, not site-specific prescriptions. See `docs/CREDITS_AND_DATA_SOURCES.md`.
